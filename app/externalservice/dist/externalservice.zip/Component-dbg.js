sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("externalservice.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);